# Hospital-Management
A hospital management system is made using Python as both the Front end and Back end with the Tkinter package
