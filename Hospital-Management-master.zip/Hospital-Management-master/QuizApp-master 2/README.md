NodeQuiz Application.
This is NodeJS powered quiz application of type Web

Dependencies:
1. Installation of Node.js 
2. Installation of MySQL
3. Install quizdb.sql on your database server and modify Database.js file as per your Database settings.

Installation:
1. In project directory run "npm install" interminal
2. "npm start" will fire node server
3. Open any Browser
4. Enter "localhost:3000"