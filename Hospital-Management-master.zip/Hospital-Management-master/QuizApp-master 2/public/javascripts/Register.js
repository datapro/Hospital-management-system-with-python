$("#toggle-register").click(function() {
  $("#Register").toggle();
});
